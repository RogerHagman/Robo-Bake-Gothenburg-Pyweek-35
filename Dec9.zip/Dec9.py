def touching(head,tail):
    if (abs(head[0] - tail[0]) <= 1) and (abs(head[1] - tail[1]) <=1):
        return True
    else:
        return False

def move(knot, dir):
    if dir == 'R':
        knot[0]+=1
    elif dir == 'L':
        knot[0]-=1
    elif dir == 'U':
        knot[1]+=1
    else:
        knot[1]-=1

def move_rope(head,rope):
    knot = rope[0]
    if touching(head,knot) == False:
        if head[0]>knot[0]:
            move(knot, 'R')
        elif head[0]<knot[0]:
            move(knot,'L')
        if head[1]>knot[1]:
            move(knot,'U')
        elif head[1]<knot[1]:
            move(knot,'D')
        if rope[1:] != []:
            move_rope(knot, rope[1:])
    
with open('Dec9') as input:
    data = input.read().split('\n')

#Part1
visited_coordinates = set()
head = [0,0]
tail = [0,0]
for line in data:
    direction = line[0]
    times = int(line[2:])
    for time in range(times):
        move(head, direction)
        move_rope(head,[tail])
        visited_coordinates.add(tuple(tail))

#Part2
visited2 = set()
head = [0,0]
tail = [0,0]
rope = [head.copy(), head.copy(), head.copy(), head.copy(), head.copy(), head.copy(), head.copy(), head.copy(), tail]
for line in data:
    direction = line[0]
    for time in range(int(line[2:])):
        move(head, direction)
        move_rope(head,rope)
        visited2.add(tuple(tail))


#print(visited_path)
#print(visited_coordinates)
#print(len(visited_coordinates))

print(len(visited2))