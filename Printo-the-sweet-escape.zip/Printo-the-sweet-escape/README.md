Printo: The Sweet Escape

Thank you for downloading our submission to the 2023 PyWeek 35 competition.
This Theme of this iteration was: "In the Shadows"

Our team Robo Bake Gothenburg consists of:
BKBender
FatherWilliam
Shmillibonka
DivineTofu

Dependencies:

Python version 3.10+
Pygame 2.3 (Previous versions might work but has not been tested)

Running the game:

Running our game should be fairly straightforward, simply execute the file named run_game.py to start the game. 

Attributions:

From OpenGameArt.org:
MrMajestatisch
David Harrington 
AntumDeluge
Death's Darling

We created the Printo 3000 artwork(shown in credits) using stable diffusion. 
Below is a website tracking some of the inspirational resources the model uses:
https://tinyurl.com/yc5u4fvb

Closing remarks:

We hope you will enjoy this game so please, Sit back relax Printo: The Sweet Escape is best enjoyed with a hot beverage and generous portion of raspberry pie.

Good Luck!